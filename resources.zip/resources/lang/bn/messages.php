<?php

return [
    'Select Employee' => 'কর্মকর্তা নির্বাচন করুন',
    'Dashboard' => 'ড্যাশবোর্ড',
    
];